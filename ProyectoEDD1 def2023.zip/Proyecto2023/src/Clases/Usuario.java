/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Andrea
 */
public class Usuario {
    public String nombre;
    public Usuario next;
    
    public Usuario(String nombre) {
        
        this.nombre = nombre;
        
        this.next = null;
    }
    
    public void addUser(String nombre) {
        this.nombre += "/" + nombre;
    }
    
    public void removeUser(String nombre) {
        this.nombre = nombre.replaceAll("/" + nombre, "");
    }
    
    public String getUsuarioString(){
        String user = this.nombre;
        return user;
    }

}
