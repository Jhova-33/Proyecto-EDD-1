/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import javax.swing.JOptionPane;

/**
 *
 * @author Andrea
 */
public class ListaUsuarios {
    public Usuario first;
    public Usuario last;
    public int size;

    public ListaUsuarios() {
        this.first = null;
        this.last = null;
        this.size = 0;
    }
    
    public boolean isEmpty() {
        return first == null;
    }
    
    public void addAtTheEnd(Usuario newUsuario) {
        if (this.isEmpty()) {
            first = last = newUsuario;
        } else {
            last.next = newUsuario;
            last = newUsuario;
        }
        size++;
    }
    
    public void delateUser(String user){
        if (!this.isEmpty()) {
            if (this.first.getUsuarioString().equals(user)) {
                this.first = this.first.next;
                size--;
                JOptionPane.showMessageDialog(null, "Usuario Eliminado");
            } else {
                Usuario temp = this.first;
                boolean found = false;
                while (temp.next != null) {
                    if (temp.next.getUsuarioString().equals(user)) {
                        found = true;
                        temp.next = temp.next.next;
                        size--;
                    } else {
                        temp = temp.next;
                    }
                }
                if (found) {
                    JOptionPane.showMessageDialog(null, "Usuario Eliminado");
                } else {
                    JOptionPane.showMessageDialog(null, "No se pudo eliminar el uusuario");

                }
            }
        }    
    }
    
}
