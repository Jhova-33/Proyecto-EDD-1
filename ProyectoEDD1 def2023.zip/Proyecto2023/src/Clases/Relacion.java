/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Andrea
 */
public class Relacion {
    public char key;
    public String relacion1;
    public String relacion2;
    public Relacion next;
    public int tamaño;

    public Relacion(String relacion1, String relacion2) {
        this.relacion1 = relacion1;
        this.relacion2 = relacion2;
    }

    public String getRelacionString(){
        String rela = this.relacion1 + "," + this.relacion2;
        return rela;
    }
        
   

}
