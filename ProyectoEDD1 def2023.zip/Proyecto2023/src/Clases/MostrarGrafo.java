/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
        
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;
import org.w3c.dom.Node;

/**
 *
 * @author Jhova33
 */

public class MostrarGrafo {
          private final Graph grafo;
          
          public MostrarGrafo() {
              grafo = new SingleGraph("Grafo de los Usuarios");
          }
          
          public void agregarunUsuario(String usuario) {
              grafo.addNode(usuario);
          }
          
          public void agregarunaRelacion(String usuarioa, String usuariob) {
              grafo.addEdge(usuarioa + " / " + usuariob, usuarioa, usuariob);
          }
          
          public void eliminarUsuario(String usuario) {
              grafo.removeNode(usuario);
          }
          
          public void enseñarGrafo() {
              grafo.display();
          }
          
          public static void main(String[] args) {
              MostrarGrafo grafoVisual = new MostrarGrafo();
              
              grafoVisual.agregarunUsuario("Usuarioa");
              grafoVisual.agregarunUsuario("Usuariob");
              grafoVisual.agregarunUsuario("Usuarioc");
              
              grafoVisual.agregarunaRelacion("Usuarioa", "Usuariob");
              grafoVisual.agregarunaRelacion("Usuariob", "Usuarioc");
              
              grafoVisual.enseñarGrafo();
          }
}
