/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Andrea
 */
public class Funciones {
    
    public ModificarGrafo grafoGuardado;
    public ListaUsuarios usuariosGuardado;
    public ListaRelaciones relacionesGuardado;
    public boolean full;

    public Funciones() {
        this.usuariosGuardado = new ListaUsuarios();
        this.relacionesGuardado = new ListaRelaciones();
        this.full = false;
    }
    

    public void cargarArchivo() {
        String info_txt = "";
        JFileChooser jf = new JFileChooser();
        jf.showOpenDialog(null);
        File archivo = jf.getSelectedFile();
        try {
            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while ((line = br.readLine()) != null) {
                if (!line.isEmpty()) {
                    info_txt += line + "\n";
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error de lectura");
        }
        try {
            if (!"".equals(info_txt)) {
                String[] arr_txt = info_txt.split("\n");
                int contador=0;
                int linea = 1;
                if (info_txt.startsWith("usuarios")){
                    contador =1;
                }
                if (info_txt.startsWith("relaciones")){
                    contador =2;
                }
                if (info_txt.startsWith("@")){
                    while (contador==1) {
                    String atributos = arr_txt[linea];
                    Usuario newUsuario = new Usuario(atributos);
                    this.usuariosGuardado.addAtTheEnd(newUsuario);
                    linea += 1;
                    }
                    while (contador==2) {
                    String[] atributos = arr_txt[linea].split(",");
                    Relacion newRelacion = new Relacion(atributos[0],atributos[1]);
                    this.relacionesGuardado.AddAtTheEnd(newRelacion);
                    linea += 1;
                    }
                }JOptionPane.showMessageDialog(null, "Archivo cargado en el sistema.");
                this.full = true;
            }else {
                JOptionPane.showMessageDialog(null, "El archivo esta vacío");
            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de lectura");
    } 
    } 
    
    public void actualizarTxt(){
        if (!(this.usuariosGuardado.isEmpty() || this.relacionesGuardado.isEmpty() )) {
            try{
                String newTxt = "";
                newTxt += "usuarios \n";
                Usuario temp1 = this.usuariosGuardado.first;
                while (temp1 != null) {
                    String newLine = temp1.nombre + "\n";
                    newTxt += newLine;
                    temp1 = temp1.next;
                }
                
                newTxt += "relaciones \n";
                Relacion temp2 = this.relacionesGuardado.first;
                while (temp2 != null) {
                    String newLine = temp2.relacion1 + ", "+temp2.relacion2+ "\n";
                    newTxt += newLine;
                    temp1 = temp1.next;
                }
                
                newTxt += "Rutas \n";
                //String textoRutas = this.grafoGuardado.rutasString(usuariosGuardado, relacionesGuardado);
                //newTxt += textoRutas;
                JFileChooser jf = new JFileChooser();
                jf.showOpenDialog(null);
                File archivo = jf.getSelectedFile();
                String ruta = archivo.getAbsolutePath();
                try (PrintWriter pw = new PrintWriter(ruta)) {
                    pw.print(newTxt);
                }
                JOptionPane.showMessageDialog(null, "Actualización exitosa.");
                this.full = true;
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error en el catch");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error, alguna de las listas se encuentra vacía");
        }
    }    
    
}
