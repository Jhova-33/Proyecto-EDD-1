/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Jhova33
 */
public class ModificarGrafo {
          private final Map<String, List<String>> relaciones;
    
               public ModificarGrafo() {
                    relaciones = new HashMap<>();
               }

               public void nuevoUsuario(String usuario) {
                    relaciones.put(usuario, new ArrayList<>());
               }

               public void eliminarUsuario(String usuario) {
                    List<String> relacionesUsuario = relaciones.get(usuario);
                    relacionesUsuario.stream().map(usuarioRelacion -> relaciones.get(usuarioRelacion)).forEachOrdered(relacionesUsuarioRelacion -> {
                        relacionesUsuarioRelacion.remove(usuario);
              });
                  relaciones.remove(usuario);
               }
                public void agregarRelaciones(String usuarioa, String usuariob) {
                    List<String> relacionesUsuarioa = relaciones.get(usuarioa);
                    List<String> relacionesUsuariob = relaciones.get(usuariob);
                    relacionesUsuarioa.add(usuariob);
                    relacionesUsuariob.add(usuarioa);
                   }

                public void mostrarlasRelaciones() {
                    relaciones.entrySet().stream().map((Map.Entry<String, List<String>> entry) -> {
                        String usuario = entry.getKey();
                        List<String> relacionesUsuario = entry.getValue();
                        System.out.println("Relaciones del usuario " + usuario + ":");
                        for (String usuarioRelacion : relacionesUsuario) {
                            System.out.println(" / " + usuarioRelacion);
                        }
                        return entry;
                    }).forEachOrdered(_item -> {
                  System.out.println("");
              });
         }
         
         public static void main(String[] args) {
                  ModificarGrafo grafo = new ModificarGrafo();
                  
                  grafo.nuevoUsuario("Usuarioa");
                  grafo.nuevoUsuario("Usuariob");
                  grafo.nuevoUsuario("Usuarioc");
                  
                  grafo.agregarRelaciones("usuarioa", "usuariob");
                  grafo.agregarRelaciones("usuariob", "usuarioc");
                  
                  grafo.mostrarlasRelaciones();
                  
                  grafo.eliminarUsuario("Usuarioa");
                          
                  grafo.mostrarlasRelaciones();
         }
         


}
