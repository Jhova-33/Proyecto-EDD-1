/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import javax.swing.JOptionPane;

/**
 *
 * @author Andrea
 */
public class ListaRelaciones {
    public Relacion first;
    public Relacion last;
    public int size;

    public ListaRelaciones() {
        this.first = null;
        this.last = null;
        this.size = 0;
    }

    
    public boolean isEmpty(){
        return first == null; 
    }    
   
    public void AddAtTheEnd (Relacion newRelacion){
        if (this.isEmpty()) {
            first = last = newRelacion;
        } else {
            last.next = newRelacion;
            last = newRelacion;
        }
        size++;
    }
    
    public void delateRelacion(String rela){
        if (!this.isEmpty()) {
            if (this.first.getRelacionString().equals(rela)) {
                this.first = this.first.next;
                size--;
                JOptionPane.showMessageDialog(null, "Relación eliminada");
            } else {
                Relacion temp = this.first;
                boolean found = false;
                while (temp.next != null) {
                    if (temp.next.getRelacionString().equals(rela)) {
                        found = true;
                        temp.next = temp.next.next;
                        size--;
                    } else {
                        temp = temp.next;
                    }
                }
                if (found) {
                    JOptionPane.showMessageDialog(null, "Relación eliminada");
                } else {

                }
            }

        }
    
    }
    
}
    
   
